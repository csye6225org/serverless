var aws = require("aws-sdk");
var ses = new aws.SES({ region: "us-east-1" });
const dynamodb = new aws.DynamoDB.DocumentClient();
aws.config.update({ region: "us-east-1" });

exports.handler = async function (event) {

    var params = {
        Destination: {
            ToAddresses: ["varadds859@gmail.com"],
        },
    
        Message: {
            Body: {
            Text: { Data: "Test" },
            },

            Subject: { Data: "Test Email" },
        },
        
        Source: "no_reply@prod.varaddesai.me",
    };

    return ses.sendEmail(params).promise()
};